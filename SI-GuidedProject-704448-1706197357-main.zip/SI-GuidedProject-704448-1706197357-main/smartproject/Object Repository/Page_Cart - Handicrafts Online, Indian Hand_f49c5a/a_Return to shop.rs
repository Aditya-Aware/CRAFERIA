<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Return to shop</name>
   <tag></tag>
   <elementGuidId>c92d92c6-db1e-49ef-af79-8bcf314dea91</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-7']/div/div/p/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.button.wc-backward</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>70f2d180-a5f9-4c62-b62b-303e95f9d282</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button wc-backward</value>
      <webElementGuid>f94e4847-5c8b-4c80-be70-d70620ec6aa8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/</value>
      <webElementGuid>9f81ccdd-beaf-4c13-bef8-38f038a70926</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Return to shop		</value>
      <webElementGuid>0c01285c-5f52-4899-be7f-2bb1ac76e597</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-7&quot;)/div[@class=&quot;entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/p[@class=&quot;return-to-shop&quot;]/a[@class=&quot;button wc-backward&quot;]</value>
      <webElementGuid>eb4521cb-17d9-41e1-ad3e-a339b3112f34</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-7']/div/div/p/a</value>
      <webElementGuid>a2cc369a-d4db-4b3f-ae95-b8cba6c3792c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Return to shop')]</value>
      <webElementGuid>37ecbefd-58d7-4e0f-80ce-786404827c97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/')])[122]</value>
      <webElementGuid>83ca6edf-58c0-4d23-9c0e-5a663aecb638</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/a</value>
      <webElementGuid>38bada1b-0234-4045-beb9-f0bdfafb5aab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/' and (text() = '
			Return to shop		' or . = '
			Return to shop		')]</value>
      <webElementGuid>3f862c8c-1d82-4f6c-9c7f-de055616e01a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
