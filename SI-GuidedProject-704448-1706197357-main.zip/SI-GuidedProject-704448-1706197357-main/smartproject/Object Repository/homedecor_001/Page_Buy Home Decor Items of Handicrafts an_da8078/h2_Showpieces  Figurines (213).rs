<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Showpieces  Figurines (213)</name>
   <tag></tag>
   <elementGuidId>2b84d84e-fe9c-4e85-912b-12de88a4e9c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/ul/li/a/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.woocommerce-loop-category__title</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>ab706008-8d59-4006-b796-aca17ab23638</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-loop-category__title</value>
      <webElementGuid>d04be8fa-183d-45bc-a12e-fe79f7b180f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Showpieces &amp; Figurines (213)		</value>
      <webElementGuid>4906f8f1-fba2-4d2c-be11-0d017445f9e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/ul[@class=&quot;products columns-4&quot;]/li[@class=&quot;product-category product first&quot;]/a[1]/h2[@class=&quot;woocommerce-loop-category__title&quot;]</value>
      <webElementGuid>f2f4072b-841f-4dd0-b53d-c438870687b1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/ul/li/a/h2</value>
      <webElementGuid>2e1e2576-cb45-4a7a-ad1c-e2163fb6d475</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>f9e9d64a-b1ed-407c-9f22-a4ac2eab5cac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
			Showpieces &amp; Figurines (213)		' or . = '
			Showpieces &amp; Figurines (213)		')]</value>
      <webElementGuid>8496e0ff-6691-41f0-a09a-677bf2da195a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
