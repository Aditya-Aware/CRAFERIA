<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_Home Decor  Items  GiftsShowpieces  Figu_871b6e</name>
   <tag></tag>
   <elementGuidId>afb86261-a11a-4cc2-a5b2-92f6484c1111</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='menu-main-menu']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#menu-main-menu</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>9e0a9e3a-5b2a-4cb1-ab41-a57a0a31ccd6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>menu-main-menu</value>
      <webElementGuid>c5dcdc76-a300-4456-9236-d719f9f4a019</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>menu nav-menu</value>
      <webElementGuid>f9f588d8-0149-4918-9a46-a09ebe14d758</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>6c2382f4-e335-464e-84ab-a57d5b482c60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Home Decor – Items &amp; Gifts

	Showpieces &amp; Figurines
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall Decor
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home Accents
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade Furnitures

	Bamboo Furniture
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
Mudha

	Mudha Stools
	Mudha chairs
	Mudha Table


Furnishings

	Cushions
	Placemats &amp; Runners
	Bedsheets
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	Tapestry
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies Bags

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
</value>
      <webElementGuid>a251f89d-22b5-479f-a140-97061c1b58ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menu-main-menu&quot;)</value>
      <webElementGuid>c7294eac-8404-4f75-9768-0818c1522979</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//ul[@id='menu-main-menu']</value>
      <webElementGuid>f0d180ac-3a06-4d5a-bef5-0ca3716cdf3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='site-navigation']/div/ul</value>
      <webElementGuid>75685c78-7651-497c-85b7-d90e5422ec32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/nav/div/ul</value>
      <webElementGuid>dabfc136-e7ce-4529-bafc-3f650d782c0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[@id = 'menu-main-menu' and (text() = 'Home Decor – Items &amp; Gifts

	Showpieces &amp; Figurines
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall Decor
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home Accents
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade Furnitures

	Bamboo Furniture
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
Mudha

	Mudha Stools
	Mudha chairs
	Mudha Table


Furnishings

	Cushions
	Placemats &amp; Runners
	Bedsheets
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	Tapestry
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies Bags

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
' or . = 'Home Decor – Items &amp; Gifts

	Showpieces &amp; Figurines
	
		Musical Showpiece
		Spiritual figurines
		Vintage Decor
		Table Organizer
		Collectibles
	

	Wall Decor
	
		Wall hanging
		Spiritual Wall hanging
		Wall Art
		Wall panels
	

	Home Accents
	
		Photo frame
		Diffuser / Burner
	

	Lamps &amp; Lightings
	Clock
	Key Holders


Handmade Furnitures

	Bamboo Furniture
	
		Bamboo Chair
		Bamboo Mudha
		Bamboo Tables
		Bamboo Shelf / Rack
	

	Bamboo Laundry &amp; Organizer Baskets
	Natural Mudha
	Pidha stools
	Iron Stools Frame
	Cane Baskets
	Sofa chair / Long chair
	Wooden Furnitures


Cane Furniture
Outdoor Furniture
Hotel &amp; Restaurant Furniture
Mudha

	Mudha Stools
	Mudha chairs
	Mudha Table


Furnishings

	Cushions
	Placemats &amp; Runners
	Bedsheets
	
		Single Bedsheets
		Double Bedsheet
	

	Blankets &amp; Quilts
	Tapestry
	
		Single Tapestry
		Round Tapestry
		Double Tapestry
	

	Bamboo Storage Basket and Utility Baskets


Ladies Bags

	handbags
	Shoulder bags
	Sling bags
	clutches
	Combo Bags
	mobile pouch / potli bag


Under 500
')]</value>
      <webElementGuid>5b200e22-82d4-4eac-b338-d3e619f9f549</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
