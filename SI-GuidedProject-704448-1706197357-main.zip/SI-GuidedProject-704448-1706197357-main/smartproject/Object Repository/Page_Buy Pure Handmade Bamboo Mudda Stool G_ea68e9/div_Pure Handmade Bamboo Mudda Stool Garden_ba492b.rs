<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Pure Handmade Bamboo Mudda Stool Garden_ba492b</name>
   <tag></tag>
   <elementGuidId>6b73bfb2-5d40-4758-a600-97d7fcc9150b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='product-5442']/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.summary.entry-summary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>8bbee941-fb31-4542-9a83-791ee010401c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>summary entry-summary</value>
      <webElementGuid>9260c3b0-7b7a-43db-9d5f-2e3d91db8e78</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
		Pure Handmade Bamboo Mudda Stool Garden Patio for Indoor/Outdoor₹1,299.00
            
                
                        
                          
                        
                    
						                            
                                
                                    
									                                
                            
							                    
                
            
			

	
			
			
									
						Color
						
							Choose an optionBlueGreenmulticolorYellowClear						
					
							
		
		
		
			
	
	
	5 in stock


	
	
		Pure Handmade Bamboo Mudda Stool Garden Patio for Indoor/Outdoor quantity
	
	

	Add to cart

	
	
	
	

		
	
	



	
	
		SKU: Mudha-069A-GREEN

	
	Category: Mudha Stools
	
	

	</value>
      <webElementGuid>a3242fa2-967d-418b-b61e-3bf50da1caff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;product-5442&quot;)/div[@class=&quot;summary entry-summary&quot;]</value>
      <webElementGuid>fb3451bc-3f65-4901-99bb-88bd78c029f1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='product-5442']/div[2]</value>
      <webElementGuid>113ff5c3-2fe9-42ca-b26a-3fcf88b743f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]</value>
      <webElementGuid>3794936c-e16d-4760-90b9-2c499a05b25e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
		Pure Handmade Bamboo Mudda Stool Garden Patio for Indoor/Outdoor₹1,299.00
            
                
                        
                          
                        
                    
						                            
                                
                                    
									                                
                            
							                    
                
            
			

	
			
			
									
						Color
						
							Choose an optionBlueGreenmulticolorYellowClear						
					
							
		
		
		
			
	
	
	5 in stock


	
	
		Pure Handmade Bamboo Mudda Stool Garden Patio for Indoor/Outdoor quantity
	
	

	Add to cart

	
	
	
	

		
	
	



	
	
		SKU: Mudha-069A-GREEN

	
	Category: Mudha Stools
	
	

	' or . = '
		Pure Handmade Bamboo Mudda Stool Garden Patio for Indoor/Outdoor₹1,299.00
            
                
                        
                          
                        
                    
						                            
                                
                                    
									                                
                            
							                    
                
            
			

	
			
			
									
						Color
						
							Choose an optionBlueGreenmulticolorYellowClear						
					
							
		
		
		
			
	
	
	5 in stock


	
	
		Pure Handmade Bamboo Mudda Stool Garden Patio for Indoor/Outdoor quantity
	
	

	Add to cart

	
	
	
	

		
	
	



	
	
		SKU: Mudha-069A-GREEN

	
	Category: Mudha Stools
	
	

	')]</value>
      <webElementGuid>dc7bdb7e-8e49-4e19-a417-e621af70b7ad</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
