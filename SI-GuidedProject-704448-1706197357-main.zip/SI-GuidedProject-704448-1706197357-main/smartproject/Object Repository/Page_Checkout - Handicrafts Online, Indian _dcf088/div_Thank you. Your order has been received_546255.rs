<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Thank you. Your order has been received_546255</name>
   <tag></tag>
   <elementGuidId>fc2be16f-1761-48bb-bac7-9b9f0b5e8dd5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-8']/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.woocommerce-order</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f95e9bec-ab9e-4dd6-be38-019829194a59</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-order</value>
      <webElementGuid>45269bec-e19f-4f79-977e-bd5ae72125dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

	
		            Thank you. Your order has been received.

            

                
					Order number:                    29821
                

                
					Date:                    February 19, 2024
                

                
					Total:                    ₹5,995.00
                

				
                    
						Payment method:                        Cash on delivery
                    

				            
            
				Pay with cash upon delivery.
		
	
	Order details

	

		
			
				Product
				Total
			
		

		
			

	
		Handmade Bamboo Mudda Chair (Set of 2) with Arm Rest- Black Color -XL size with Table × 1	

	
		₹5,845.00	



		

		
								
						Subtotal:
						₹5,845.00
					
										
						Shipping:
						₹150.00 via Box packing charges (NOTE : *Shipping charger will be calculation after courier partner discuss )
					
										
						Payment method:
						Cash on delivery
					
										
						Total:
						₹5,995.00
					
										
	

	

	</value>
      <webElementGuid>72b09cf8-b490-4690-a7e1-0f7bcf526c9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-8&quot;)/div[@class=&quot;entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/div[@class=&quot;woocommerce-order&quot;]</value>
      <webElementGuid>92864baf-f041-4eaa-aeed-5fdb34183263</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-8']/div/div/div</value>
      <webElementGuid>b63ffb27-8a73-4b96-b010-66d0fc379250</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//article/div/div/div</value>
      <webElementGuid>8bb8ea4c-eece-4133-ad0a-72418dffa23d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

	
		            Thank you. Your order has been received.

            

                
					Order number:                    29821
                

                
					Date:                    February 19, 2024
                

                
					Total:                    ₹5,995.00
                

				
                    
						Payment method:                        Cash on delivery
                    

				            
            
				Pay with cash upon delivery.
		
	
	Order details

	

		
			
				Product
				Total
			
		

		
			

	
		Handmade Bamboo Mudda Chair (Set of 2) with Arm Rest- Black Color -XL size with Table × 1	

	
		₹5,845.00	



		

		
								
						Subtotal:
						₹5,845.00
					
										
						Shipping:
						₹150.00 via Box packing charges (NOTE : *Shipping charger will be calculation after courier partner discuss )
					
										
						Payment method:
						Cash on delivery
					
										
						Total:
						₹5,995.00
					
										
	

	

	' or . = '

	
		            Thank you. Your order has been received.

            

                
					Order number:                    29821
                

                
					Date:                    February 19, 2024
                

                
					Total:                    ₹5,995.00
                

				
                    
						Payment method:                        Cash on delivery
                    

				            
            
				Pay with cash upon delivery.
		
	
	Order details

	

		
			
				Product
				Total
			
		

		
			

	
		Handmade Bamboo Mudda Chair (Set of 2) with Arm Rest- Black Color -XL size with Table × 1	

	
		₹5,845.00	



		

		
								
						Subtotal:
						₹5,845.00
					
										
						Shipping:
						₹150.00 via Box packing charges (NOTE : *Shipping charger will be calculation after courier partner discuss )
					
										
						Payment method:
						Cash on delivery
					
										
						Total:
						₹5,995.00
					
										
	

	

	')]</value>
      <webElementGuid>f55fcf95-1aa9-4f2e-8bb0-9732e812e6d6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
