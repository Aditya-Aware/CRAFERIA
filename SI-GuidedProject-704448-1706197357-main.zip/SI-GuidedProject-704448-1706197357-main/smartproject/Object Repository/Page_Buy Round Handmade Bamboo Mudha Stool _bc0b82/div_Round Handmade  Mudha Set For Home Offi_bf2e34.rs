<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Round Handmade  Mudha Set For Home Offi_bf2e34</name>
   <tag></tag>
   <elementGuidId>37aedc36-4d6e-4ae7-a3de-521ad106a62a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='product-5437']/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.summary.entry-summary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>944bd063-2570-4970-ba90-281209db6c00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>summary entry-summary</value>
      <webElementGuid>23daf2b4-e7a8-4952-b209-79773f41db44</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
		Round Handmade  Mudha Set For Home Office Garden Outdoor₹1,500.00
            
                
                        
                          
                        
                    
						                            
                                
                                    
									                                
                            
							                    
                
            
			

	
			
			
									
						Color
						
							Choose an optionBlueOrangeRedClear						
					
							
		
		
		
			
	
	
		Round Handmade  Mudha Set For Home Office Garden Outdoor quantity
	
	

	Add to cart

	
	
	
	

		
	
	



	
	
		SKU: Blue_mudha

	
	Category: Mudha Stools
	
	

	</value>
      <webElementGuid>c0b8e94e-00c5-4c75-bfce-a899112c4297</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;product-5437&quot;)/div[@class=&quot;summary entry-summary&quot;]</value>
      <webElementGuid>9bc76674-63f8-4c0d-8b76-ec5b73879637</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='product-5437']/div[2]</value>
      <webElementGuid>b0f7fe17-7726-4d4f-a76c-25ea526eeb89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]</value>
      <webElementGuid>74a386a6-5c58-42f3-988e-6ff72e77437a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
		Round Handmade  Mudha Set For Home Office Garden Outdoor₹1,500.00
            
                
                        
                          
                        
                    
						                            
                                
                                    
									                                
                            
							                    
                
            
			

	
			
			
									
						Color
						
							Choose an optionBlueOrangeRedClear						
					
							
		
		
		
			
	
	
		Round Handmade  Mudha Set For Home Office Garden Outdoor quantity
	
	

	Add to cart

	
	
	
	

		
	
	



	
	
		SKU: Blue_mudha

	
	Category: Mudha Stools
	
	

	' or . = '
		Round Handmade  Mudha Set For Home Office Garden Outdoor₹1,500.00
            
                
                        
                          
                        
                    
						                            
                                
                                    
									                                
                            
							                    
                
            
			

	
			
			
									
						Color
						
							Choose an optionBlueOrangeRedClear						
					
							
		
		
		
			
	
	
		Round Handmade  Mudha Set For Home Office Garden Outdoor quantity
	
	

	Add to cart

	
	
	
	

		
	
	



	
	
		SKU: Blue_mudha

	
	Category: Mudha Stools
	
	

	')]</value>
      <webElementGuid>fb92c740-f0db-4f6a-824b-fd175ad930e9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
